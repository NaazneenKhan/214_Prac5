#ifndef ROOMS_H
#define ROOMS_H

class Rooms {
};

#endif
