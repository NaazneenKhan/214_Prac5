#ifndef SMARTROOMADAPTER_H
#define SMARTROOMADAPTER_H

#include "Rooms.h"

class SmartRoomAdapter : public Rooms {
};

#endif
